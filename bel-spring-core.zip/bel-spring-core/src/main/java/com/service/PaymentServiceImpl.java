package com.service;

import org.springframework.stereotype.Service;

import com.model.CardPayment;
import com.model.Payment;
@Service
public class PaymentServiceImpl implements PaymentService{

	@Override
	public void processPayment(Payment payment) {
		System.out.println("\n==========PAYMENT==========");
		System.out.println("Payment Type : " + payment.paymentType());
		System.out.println("Amount 💲 : " + payment.amount());
		if(payment instanceof CardPayment card) {
			System.out.println("Card : " + maskCard(card.cardNumber()));
			
		}
		System.out.println("Payment Sucessfull......!");
	}
		private String maskCard(String cardnumber) {
			if(cardnumber.length() <=4) {
				return cardnumber;
			}
			return "XXXX-XXXX-XXXX-"+cardnumber.substring(cardnumber.length()-4);
		
		}
		
	}


