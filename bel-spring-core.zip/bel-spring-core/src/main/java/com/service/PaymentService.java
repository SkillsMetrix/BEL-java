package com.service;

import com.model.Payment;

public interface PaymentService {
	public void processPayment(Payment payment);
}
