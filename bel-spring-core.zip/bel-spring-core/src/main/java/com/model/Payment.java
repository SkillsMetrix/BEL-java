package com.model;

public sealed interface Payment permits UpiPayment,CardPayment,WalletPayment{
	
	double amount();
	
	default String paymentType() {
		return getClass().getSimpleName();
	}

}
