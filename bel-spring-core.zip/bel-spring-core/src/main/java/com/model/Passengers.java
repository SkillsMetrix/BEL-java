package com.model;

public record Passengers(String name,String email) {

	@Override
	public String toString() {
		return name() + "<" + email() + ">";
	}
	
	
}
