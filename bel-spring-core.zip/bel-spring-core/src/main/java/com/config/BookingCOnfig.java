package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.repo.FlightRepoImpl;
import com.service.BookingServiceImpl;
@Configuration
@ComponentScan("com")
public class BookingCOnfig {
	/*
	 * @Bean public FlightRepoImpl flightRepoImpl() { return new FlightRepoImpl(); }
	 * 
	 * @Bean public BookingServiceImpl bookingServiceImpl(FlightRepoImpl
	 * flightRepoImpl) { return new BookingServiceImpl(flightRepoImpl); }
	 */
}
