package com.bel.bel_spring_core;

import java.util.List;
import java.util.concurrent.Future;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.BookingCOnfig;
import com.exception.BookingException;
import com.executer.BookingTastExecuter;
import com.model.CardPayment;
import com.model.Flight;
import com.model.Passengers;
import com.model.Payment;
import com.service.BookingService;
import com.service.BookingServiceImpl;
import com.service.PaymentService;

 public class BelSpringCoreApplication {

	public static void main(String[] args) {
		ApplicationContext context= new AnnotationConfigApplicationContext(
				BookingCOnfig.class);
 		BookingTastExecuter tastExecuter= context.getBean(BookingTastExecuter.class);
		System.out.println("=========Running APP===========");
		Future<List<Flight>> delhimumbai= tastExecuter.searchFlight("Delhi", "Mumbai");
		System.out.println("Delhi -Mumbai Search");
		try {
		delhimumbai.get().forEach(System.out ::println);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		Future<List<Flight>> delhimumbai2= tastExecuter.searchFlight("Delhi", "Mumbai");
		System.out.println("Delhi -Mumbai Search");
		try {
		delhimumbai2.get().forEach(System.out ::println);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		Future<List<Flight>> delhimumbai3= tastExecuter.searchFlight("Delhi", "Mumbai");
		System.out.println("Delhi -Mumbai Search");
		try {
		delhimumbai3.get().forEach(System.out ::println);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		Future<List<Flight>> delhimumbai4= tastExecuter.searchFlight("Delhi", "Mumbai");
		System.out.println("Delhi -Mumbai Search");
		try {
		delhimumbai4.get().forEach(System.out ::println);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		tastExecuter.shutdown();
	}

}
