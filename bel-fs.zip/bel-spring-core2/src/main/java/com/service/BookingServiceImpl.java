package com.service;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exception.BookingException;
import com.model.Flight;
import com.model.Passengers;
import com.model.Payment;
import com.repo.FlightRepo;
@Service
public class BookingServiceImpl implements BookingService{
	
	private  FlightRepo repo;
	private  List<Flight> flights;
	
	private PaymentService paymentService;
	@Autowired
	public BookingServiceImpl(FlightRepo repo,PaymentService paymentService) {
		super();
		this.repo = repo;
		this.flights= repo.findAll();
		this.paymentService=paymentService;
	}
	public Optional<Flight> getFlight(String fno ){
		return flights.stream().filter(f -> f.flightNumber().equals(fno)).findFirst();
		
	}
	@Override
	public void bookPassenger(String fno, Passengers passengers,Payment payment) throws BookingException {
		Flight flight= getFlight(fno)
				.orElseThrow(() -> new BookingException("Flight " + fno + " not found"));
		if(flight.passengers().size() >=2) {
			
			throw new BookingException("Flight " + fno + " is fully booked");
		}
		if(payment.amount() !=flight.price().doubleValue()) {
			throw new BookingException("Payment amount does not match with flight price");
		}
		paymentService.processPayment(payment);
 		flight.addPassenger(passengers);
		System.out.println("Booking Confirmed for "+passengers.name() + " on flight "+ fno);		
	}
	@Override
	public List<Flight> searchFlight(String origin, String destination) {
		
		return flights.stream()
				.filter(f -> f.origin().equalsIgnoreCase(origin))
				.filter(f -> f.destination().equalsIgnoreCase(destination))
				.sorted(Comparator.comparing(Flight :: departureTime))
				.collect(Collectors.toList());
		
		
	}
	@Override
	public BigDecimal calculateRevenue() {
		return flights.stream()
				.map(f -> f.price().multiply(BigDecimal.valueOf(f.passengers().size())))
				.reduce(BigDecimal.ZERO, BigDecimal::add);
		
		
	}
	

}
