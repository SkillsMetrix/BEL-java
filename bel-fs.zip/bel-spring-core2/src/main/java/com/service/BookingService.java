package com.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import com.exception.BookingException;
import com.model.Flight;
import com.model.Passengers;
import com.model.Payment;

public interface BookingService {
	public void bookPassenger(String fno,Passengers passengers,Payment payment)throws BookingException;

	public List<Flight> searchFlight(String origin, String destination);

	public Optional<Flight> getFlight(String flightno);

	public BigDecimal calculateRevenue();

}
