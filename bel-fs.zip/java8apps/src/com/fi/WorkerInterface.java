package com.fi;

@FunctionalInterface
public interface WorkerInterface {
public void doSomeWork();
}
