package com.fi;

public class WorkerImpl {
	
	public static void execute(WorkerInterface worker) {
		worker.doSomeWork();
	}
	public static void main(String[] args) {
		// fatty classes
		execute(new WorkerInterface() {
			
			@Override
			public void doSomeWork() {
			System.out.println("called");
				
			}
		});
		//lambda Use
		execute(()-> System.out.println("called with lambda"));
	}
		

}
