package flightapp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public record Flight (
	 String flightNumber,
	 String origin,
	 String destination,
	 LocalDateTime departureTime,
	 BigDecimal price,
	 List<Passengers> passengers) {
	public Flight{
		if(passengers == null) {
			throw new NullPointerException("Passengers must not be null");
		}
		var copy= new ArrayList<>(passengers);
		passengers= copy;
	}
	public  Flight (
			 String flightNumber,
			 String origin,
			 String destination,
			 LocalDateTime departureTime,
			 BigDecimal price) {
		this(flightNumber,origin,destination,departureTime,price,List.of());
	}
	@Override
	public String toString() {
		return String.format("%s (%s -> %s) %sPrice: %s", 
			flightNumber,origin,destination,departureTime,price);
	}
	public void addPassenger(Passengers p) {
		passengers.add(p);
		
	}
	public boolean removePassengerByEmail(String email) {
		return passengers.removeIf(p -> p.email().equalsIgnoreCase(email));
	}
	
	
	
	
	
	
	
	
}
	