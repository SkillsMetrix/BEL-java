package flightapp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class BookingService {
	private List<Flight> flights;
	private DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm");
	
	public BookingService() {
		flights= new ArrayList<>(List.of(
				
				new Flight("AI101", "Delhi", "Mumbai", LocalDateTime.now().plusHours(5), BigDecimal.valueOf(5500),
					 List.of(new Passengers("Amar", "amar@mail.com"),
						new Passengers("Aumit", "sumit@mail.com"))),
				
				new Flight("AI102", "Delhi", "Bangalore", LocalDateTime.now().plusHours(3), BigDecimal.valueOf(6500),
						 List.of(new Passengers("Amar", "amar@mail.com"))),
				new Flight("AI103", "Mumbai", "Chennai", LocalDateTime.now().plusHours(6), BigDecimal.valueOf(4800),
						 List.of()),
				new Flight("AI104", "Delhi", "Mumbai", LocalDateTime.now().plusHours(2), BigDecimal.valueOf(6000),
						 List.of(new Passengers("Harish", "harish@mail.com")))
						
				));}

	public void cancelBooking(String flightNo,String email)throws BookingException{
		var flight= getFlight(flightNo)
				.orElseThrow(()-> new BookingException("Flight no not found"));
		if(flight.removePassengerByEmail(email)) {
			System.out.println("Booking cancelled for: "+ email + " on flight "+ flightNo);
		}else {
			throw new BookingException("Passenger details not found");
		}
	}
	public List<Flight> searchFlightByTimeRange(LocalDateTime start, LocalDateTime end){
		return flights.stream()
				.filter(f -> !f.departureTime().isBefore(start) &&  !f.departureTime().isAfter(end))
				.collect(Collectors.toList());
		
	}
	public List<Flight> searchFlight(String origin,String dest){
		return flights.stream()
				.filter(f -> f.origin().equalsIgnoreCase(origin))
				.filter(f -> f.destination().equalsIgnoreCase(dest))
				.sorted(Comparator.comparing(Flight :: departureTime))
				.collect(Collectors.toList());
	}
	
	public Optional<Flight> getFlight(String fno ){
		return flights.stream().filter(f -> f.flightNumber().equals(fno)).findFirst();
		
	}
	
	public void bookPassenger(String fno, Passengers passengers) throws BookingException {
		Flight flight= getFlight(fno)
				.orElseThrow(() -> new BookingException("Flight " + fno + " not found"));
		if(flight.passengers().size() >=2) {
			
			throw new BookingException("Flight " + fno + " is fully booked");
		}
		flight.addPassenger(passengers);
		System.out.println("Booking Confirmed for "+passengers.name() + " on flight "+ fno);
	}
	
	public void calculateRevenue() {
		BigDecimal total= flights.stream()
				.map(f -> f.price().multiply(BigDecimal.valueOf(f.passengers().size())))
				.reduce(BigDecimal.ZERO, BigDecimal::add);
		System.out.println("Total Revenue "+ total);
	}
	public void showBookings() {
		flights.forEach(flight -> {
			System.out.println("\n Flight "+ flight.flightNumber() + " (" + flight.origin() + "-> " +flight.destination()
			+") "+ flight.departureTime().format(formatter)+ "Price "+ flight.price());
			if( flight.passengers().isEmpty()) {
				System.out.println("No Passengers booked yet");
			}else {
				flight.passengers().forEach(p -> System.out.println(" - "+ p));
			}
		});
	}
	
}
