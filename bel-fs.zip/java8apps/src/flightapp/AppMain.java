package flightapp;

import java.time.LocalDateTime;

public class AppMain {

	public static void main(String[] args) {
		BookingService service= new BookingService();
		System.out.println("Searching Flight............!");
		service.searchFlight("Delhi", "Mumbai").forEach(System.out :: println);
		
		/*
		 * System.out.println("Booking flight..........!"); try {
		 * service.bookPassenger("AI101", new Passengers("Santosh","san@mail.com"));
		 * //service.bookPassenger("AI102", new Passengers("hitesh","hitesh@mail.com"));
		 * //service.bookPassenger("AI101", new Passengers("Santosh2","san@mail.com"));
		 * }catch (BookingException e) { System.out.println(e.getMessage()); } try {
		 * 
		 * service.bookPassenger("AI102", new Passengers("hitesh","hitesh@mail.com"));
		 * //service.bookPassenger("AI101", new Passengers("Santosh2","san@mail.com"));
		 * }catch (BookingException e) { System.out.println(e.getMessage()); }
		 */
		service.showBookings();
		//service.calculateRevenue();
		service.searchFlightByTimeRange(LocalDateTime.now(), LocalDateTime.now().plusHours(2))
		.forEach(System.out :: println);
 
	}

}
