package paymentapp;

public class PaymentProcessor {
	
	public static String process(Payment payment) {
		return switch(payment) {
		case UpiPayment(String upiID,double amt) -> 
			"Processing UPI payment "+upiID + " Amount "+ amt;
		case CardPayment(String card,double amt) -> 
			"Processing Card payment "+card + " Amount "+ amt;
		case WalletPayment w ->
			"Processing Wallte payment "+w.walletId() + " Amount "+ w.amount();
		};
	}

}
