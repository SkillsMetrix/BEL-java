package paymentapp;

public sealed interface Payment permits UpiPayment,CardPayment,WalletPayment{

}
