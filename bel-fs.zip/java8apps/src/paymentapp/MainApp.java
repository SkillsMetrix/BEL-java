package paymentapp;

public class MainApp {

	public static void main(String[] args) {
	
		Payment p1= new UpiPayment("amar@ybl", 100);
		
		System.out.println(PaymentProcessor.process(p1));

	}

}
