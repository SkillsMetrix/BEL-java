package paymentapp;

public record UpiPayment(String upiId,double amount) implements Payment {

}
