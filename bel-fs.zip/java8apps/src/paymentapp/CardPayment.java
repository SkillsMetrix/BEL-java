package paymentapp;

public record CardPayment(String upiId,double amount) implements Payment{

}
