package paymentapp;

public final class WalletPayment implements Payment {

	private final String walletID;
	private final double amount;
	public WalletPayment(String walletID, double amount) {
		super();
		this.walletID = walletID;
		this.amount = amount;
	}
	public String walletId() {
		return walletID;
	}
	public double amount() {
		return amount;
	}
	
	
}
