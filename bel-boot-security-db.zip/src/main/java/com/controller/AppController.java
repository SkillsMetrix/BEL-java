package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.service.UserService;

@Controller
@EnableMethodSecurity
public class AppController {
	@Autowired
	private UserService service;
	@GetMapping("/welcome")
	public String sayWelcome() {
		return "welcome";
	}
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	@PostMapping("/saveUser")
	public String addUser(@RequestParam String username,@RequestParam String password,@RequestParam String role) {
		service.addUser(username, password, role);
		return "redirect:/login";
		
	}
	@GetMapping("/student")
	@PreAuthorize("hasRole('STUDENT')")
	public String student() {
		return "student";
	}
	@GetMapping("/access-denied")
	public String ad() {
		return "access-denied";
	}
	@GetMapping("/trainer")
	@PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
	public String trainer() {
		return "trainer";
	}
	@GetMapping("/admin")
	@PreAuthorize("hasRole('ADMIN')")
	public String admin() {
		return "admin";
	}
	@GetMapping("/home")
	public String home() {
		return "home";
	}
}
