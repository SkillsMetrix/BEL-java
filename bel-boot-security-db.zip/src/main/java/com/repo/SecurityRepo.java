package com.repo;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.entity.AppUser;
@Repository
public interface SecurityRepo extends CrudRepository<AppUser, Integer>{
	Optional<AppUser> findByUsername(String username);

}
